# Validación pendiente en Android

No se marca ninguna prueba de ejecución como superada hasta realizarla en un dispositivo o emulador.

## Compilación y activación
- [ ] `./gradlew assembleDebug` con JDK 17 y SDK 35.
- [ ] Instalar, habilitar y seleccionar teclado en Android 8, 13 y 15.
- [ ] Verificar que no se solicita permiso de superposición.
- [ ] Probar rotación, navegación por gestos y pantalla pequeña.

## Escritura
- [ ] Escribir «¡Qué pingüino tan rápido! ¿Dónde está la niña?» usando pulsación prolongada.
- [ ] Cambiar a EN, números, símbolos y mayúsculas sin perder el texto del chat.
- [ ] Verificar borrar, enviar, siguiente y salto de línea según el campo.
- [ ] Campos password de texto, web y numéricos no producen revisiones.
- [ ] Selecciones, cursor intermedio y emoji no causan modificaciones imprevistas.

## Navegación y Minecraft
- [ ] Abrir chat de Minecraft Bedrock y buscar Chunkbase desde el teclado.
- [ ] Confirmar que la búsqueda no aparece en el chat.
- [ ] Cargar el sitio HTTPS y usar mapa, zoom y desplazamiento.
- [ ] Tocar campo de semilla, activar «Escribir web» e introducir semilla; comprobar que el chat no cambia.
- [ ] Probar selección de versión/edición, estructura, copia de coordenadas y vuelta al juego.
- [ ] Probar tanto mundo local como servidor multijugador.
- [ ] Verificar comportamiento sin red, TLS inválido y sitios que rechacen WebView.

## Pestañas y datos
- [ ] Abrir dos páginas, alternar y cerrar cada una.
- [ ] Navegar atrás/adelante y verificar títulos, favicons e historial.
- [ ] Crear 12 pestañas y verificar el aviso de límite.
- [ ] Cerrar el proceso y comprobar restauración de URLs/títulos.
- [ ] Borrar historial; borrar datos globales y reiniciar el teclado para comprobar que no reaparecen.
- [ ] Medir consumo de memoria con varios mapas; no publicar con cierres por memoria.

## Revisión
- [ ] Sin consentimiento, capturar tráfico y confirmar ausencia de POST de gramática.
- [ ] Con servidor de pruebas configurado, verificar solicitudes ES y EN.
- [ ] Introducir errores de concordancia y aceptar propuestas.
- [ ] Mover cursor/cambiar texto antes de recibir una propuesta: no aplicar contexto obsoleto.
- [ ] Desactivar revisión, comprobar que no se programan nuevas consultas.
- [ ] Servidor caído, lento o respuesta inválida: la escritura sigue disponible.
- [ ] Verificar ortografía con y sin diccionario Android; identificar si el proveedor opera offline.

## Publicación
- [ ] Auditoría de privacidad y accesibilidad; política de privacidad y ficha de seguridad de datos.
- [ ] Firma de lanzamiento bajo control del propietario; nunca compartir la clave privada.
- [ ] Pruebas cerradas antes de uso diario y cumplimiento de requisitos vigentes de Play Store.
