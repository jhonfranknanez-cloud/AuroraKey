# Aurora Key — Android · prototipo 0.1

Un teclado español/inglés con un navegador dentro de su propia superficie. Abre el chat de tu juego, abre Aurora y consulta una web sin lanzar otro navegador. Sin superposición sobre otras aplicaciones.

**Estado real:** código fuente de un prototipo nativo en Kotlin. No se ha compilado ni ejecutado en un dispositivo en este entorno: no hay Android SDK ni JDK 17. No se incluye un APK validado. No debe considerarse aún un teclado de uso diario ni una versión lista para Play Store.

## Abrir y compilar

1. Instala Android Studio con JDK 17 y Android SDK 35.
2. Abre esta carpeta como proyecto y permite la sincronización de Gradle. Se incluye Gradle Wrapper 8.9; la primera ejecución necesita internet.
3. Ejecuta `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
4. El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.
5. Instálalo en un dispositivo Android 8.0 o posterior. Abre Aurora Key, pulsa **Habilitar teclado** y luego **Elegir Aurora Key**.
6. Empieza probando en el campo de texto de la pantalla de configuración antes de usar un juego.

## Incluido en el código

- Servicio Android `InputMethodService`, no una web que simule un teclado.
- Distribuciones ES/EN, Ñ, mayúsculas, símbolos, números, acentos por pulsación prolongada y teclas de acción.
- Consulta separada del campo de la aplicación anfitriona: las búsquedas no se escriben en el chat.
- Búsqueda DuckDuckGo y navegación directa por URL HTTPS. Google puede abrirse escribiendo su dirección, pero no hay selector de proveedor todavía.
- WebView con controles atrás, adelante, recargar y altura ampliada.
- Hasta 12 pestañas, cada una con su WebView. Lista de filas horizontales con título, dominio, cierre e icono cuando la web lo suministra.
- Persistencia local de URL/título de pestañas y últimos 100 sitios distintos visitados. No se persisten favicon, posición del mapa ni formularios.
- Historial local, borrado del historial y borrado global desde configuración. Para vaciar también las pestañas ya abiertas en memoria, reinicia el teclado tras el borrado global.
- Sugerencias ortográficas usando el servicio de revisión de Android en el idioma seleccionado. Dependen de que el dispositivo disponga de un corrector y diccionario para ese idioma.
- Revisión gramatical tras 900 ms de pausa, opcional, compatible con API LanguageTool `/v2/check`. Requiere servidor HTTPS propio o contratado; no se incluye un servicio público gratuito ni claves.
- Correcciones mediante aceptación, no reemplazos silenciosos. Se comprueba que el contexto siga siendo el mismo antes de aplicar una propuesta.
- Revisión desactivada en campos identificados por Android como contraseñas y cuando hay una selección de texto.
- Apariencia oscura aurora mediante degradados ligeros, sin recursos remotos ni animaciones constantes.

## Escribir dentro de una página

Toca primero el campo de la web y luego **Escribir web**. Las teclas intentan enviar texto a la conexión de entrada de WebView, nunca al chat del juego mientras ese modo está activo. Este puente es **experimental**: requiere pruebas con versiones de Android/WebView y con campos HTML complejos. Si no está disponible, esa entrada puede no funcionar. Es el principal punto técnico pendiente para formularios como semilla/versión en Chunkbase.

La selección y copia de texto utiliza el menú nativo de WebView. No hay aún un botón de pegado dedicado; el portapapeles se puede usar desde las funciones del campo anfitrión según permita la aplicación.

## Privacidad y gramática

La revisión remota empieza apagada. En Ajustes se configura una dirección HTTPS compatible y se acepta explícitamente el envío. El cuerpo del POST contiene `language=es` o `en-US`, y `text` (hasta 1.200 caracteres anteriores al cursor). El servidor responde con `matches`, `offset`, `length` y `replacements`, como LanguageTool.

No hay envío a un proveedor predeterminado. El servidor elegido podría registrar textos: revisa sus condiciones o usa un servidor propio. Desactivar la revisión evita nuevas solicitudes, pero una ya enviada no se puede retirar. La detección de contraseñas depende de que la aplicación marque correctamente el campo; no puede reconocer todos los secretos escritos en campos normales.

El corrector ortográfico del sistema es independiente de esta conexión: **su funcionamiento sin conexión y su política de datos dependen del proveedor configurado en Android**. Este prototipo aún no incluye diccionarios propios empaquetados. Si necesitas garantía estricta de funcionamiento local, ese es un requisito de la siguiente fase.

Las webs visitadas reciben las solicitudes normales de navegación y pueden usar cookies y almacenamiento propio. Se bloquean cookies de terceros, contenido mixto, acceso a archivos locales y esquemas externos. Se mantiene la validación TLS de WebView; no se ignoran errores de certificado. No hay interfaz JavaScript nativa expuesta. No hay telemetría ni copia de seguridad automática de datos de la app.

## Pendiente antes de una beta

- Compilar, resolver cualquier incidencia de compilación y ejecutar la matriz de pruebas adjunta.
- Validar y reforzar el puente de escritura en WebView, particularmente con Chunkbase.
- Dictado por voz: **no implementado**; se añadirá con permiso explícito y evaluación de disponibilidad local.
- Panel de emojis, edición avanzada, pegado dedicado, repetición al mantener borrar y escritura gestual: no implementados.
- Diccionarios offline propios y verificación de que el revisor del sistema no hace solicitudes remotas.
- Selector Google/DuckDuckGo, favoritos, modo privado y controles por aplicación.
- Explicaciones gramaticales completas: actualmente se muestran sustituciones, no una tarjeta explicativa.
- Límite de memoria más refinado para pestañas con mapas pesados; descarga de páginas inactivas.
- Accesibilidad, rotación, insets y tamaños de pantalla; ajuste fino visual.
- Endurecimiento del servicio remoto: autenticación si el proveedor la requiere, límites, retención y política de privacidad.
- Portugués, francés e italiano después de validar español e inglés.
- Tor no forma parte de esta versión.

## Límites del concepto

El teclado requiere un campo de entrada activo. No mantiene Minecraft funcionando si el juego decide pausar al abrir el chat. El área disponible limita mapas y herramientas de escritorio. Android puede cerrar el proceso; se restauran direcciones, no necesariamente el estado exacto del sitio. Solo se revisa el contexto accesible alrededor del cursor, no un documento completo. No se garantiza compatibilidad universal con juegos, formularios, autenticación web ni páginas que rechacen WebView.

## Organización

- `MainActivity.kt`: activación, consentimiento y configuración.
- `AuroraIme.kt`: teclas, navegación, pestañas, historial y revisiones.
- `res/xml/method.xml`: idiomas y declaración del método de entrada.
- `PRUEBAS.md`: criterios de aceptación para dispositivos reales.

Nombre de trabajo: **Aurora Key**. Sin relación oficial con Google, Gemini, Minecraft, Chunkbase o LanguageTool.
