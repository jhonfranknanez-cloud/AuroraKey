package com.aurora.key

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
 override fun onCreate(state: Bundle?) {
  super.onCreate(state)
  val p = getSharedPreferences("aurora", MODE_PRIVATE)
  val page = LinearLayout(this).apply { orientation = 1; setPadding(28,48,28,24); setBackgroundColor(Color.rgb(10,12,23)) }
  fun text(s: String, size: Float = 16f) { page.addView(TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); setPadding(0,12,0,16) }) }
  fun button(s: String, action: () -> Unit) { page.addView(Button(this).apply { text=s; setOnClickListener { action() } }) }
  text("AURORA KEY", 30f)
  text("Tu partida. Tu búsqueda.\nTeclado experimental · Español / English",18f)
  button("1 · Habilitar teclado") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
  button("2 · Elegir Aurora Key") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
  text("Revisión gramatical opcional",21f)
  text("Desactivada por defecto. Al activarla, tras una pausa se enviarán hasta 1.200 caracteres anteriores al cursor al servidor HTTPS que configures, salvo campos identificados como contraseñas. Ese servidor puede registrar los textos según su política. No se envían búsquedas. Las propuestas solo se aplican al tocarlas.")
  val endpoint = EditText(this).apply { hint="https://tu-servidor/v2/check"; setSingleLine(); setText(p.getString("endpoint","")); inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI }
  page.addView(endpoint)
  val consent = CheckBox(this).apply { text="Consiento el envío de texto para revisar gramática"; isChecked=p.getBoolean("grammar",false) }; page.addView(consent)
  button("Guardar privacidad y servidor") {
   val url=endpoint.text.toString().trim()
   if(consent.isChecked && (!url.startsWith("https://") || android.net.Uri.parse(url).host.isNullOrBlank())) Toast.makeText(this,"Introduce un servidor HTTPS compatible con LanguageTool",Toast.LENGTH_LONG).show()
   else { p.edit().putString("endpoint",url).putBoolean("grammar",consent.isChecked).apply(); Toast.makeText(this,"Configuración guardada",Toast.LENGTH_SHORT).show() }
  }
  text("El servidor no está incluido ni contratado. No hay claves incrustadas ni telemetría. El historial y las direcciones de pestañas se guardan solo en este dispositivo. Android puede recargar páginas al recuperar memoria.")
  button("Borrar historial, pestañas y datos web") {
   p.edit().remove("tabs").remove("history").apply()
   android.webkit.CookieManager.getInstance().removeAllCookies(null)
   android.webkit.WebStorage.getInstance().deleteAllData()
   android.webkit.WebView(this).apply { clearCache(true); clearHistory(); destroy() }
   Toast.makeText(this,"Datos guardados borrados. Las pestañas activas se cerrarán al reiniciar el teclado.",Toast.LENGTH_LONG).show()
  }
  page.addView(EditText(this).apply { hint="Prueba aquí el teclado…"; minLines=2 })
  setContentView(ScrollView(this).apply { addView(page) })
 }
}
