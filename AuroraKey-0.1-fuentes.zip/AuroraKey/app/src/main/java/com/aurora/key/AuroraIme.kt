package com.aurora.key

import android.inputmethodservice.InputMethodService
import android.os.*
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.inputmethod.*
import android.view.textservice.*
import android.text.InputType
import android.webkit.*
import android.widget.*
import org.json.*
import java.net.*
import java.util.Locale
import java.util.concurrent.Executors

class AuroraIme : InputMethodService(), SpellCheckerSession.SpellCheckerSessionListener {
 private val prefs by lazy { getSharedPreferences("aurora", MODE_PRIVATE) }
 private val handler=Handler(Looper.getMainLooper())
 private val network=Executors.newSingleThreadExecutor()
 private lateinit var root: LinearLayout
 private lateinit var body: LinearLayout
 private lateinit var suggestions: LinearLayout
 private var es=true
 private var shift=false
 private var symbols=false
 private var mode="keys"
 private var query=""
 private var secret=false
 @Volatile private var epoch=0
 private var hasSelection=false
 private var spell: SpellCheckerSession?=null
 private var lastWord=""
 private var lastContext=""
 private var spellEpoch=0
 private val tabs=mutableListOf<Tab>()
 private var selected=0
 private var tall=false
 private var browserTyping=false
 private var webConnection: InputConnection?=null
 private data class Tab(var url:String, var title:String="Nueva pestaña", var icon:Bitmap?=null, var web:WebView?=null)
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun panel()=LinearLayout(this).apply { orientation=1 }
 private fun row()=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
 private fun label(s:String)=TextView(this).apply { text=s; textSize=13f; setTextColor(Color.rgb(189,195,220)); setPadding(dp(10),dp(6),dp(10),dp(6)) }
 private fun button(s:String, action:()->Unit)=Button(this).apply {
  text=s; isAllCaps=false; textSize=13f; minWidth=0; minimumWidth=0; setPadding(0,0,0,0); setTextColor(Color.WHITE)
  background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(0xff24344c.toInt(),0xff241d3c.toInt())).apply { cornerRadius=dp(10).toFloat(); setStroke(dp(1),0xff38455d.toInt()) }
  setOnClickListener { action() }
 }
 private fun LinearLayout.key(s:String, weight:Float=1f, action:()->Unit):Button {
  val b=button(s,action); addView(b,LinearLayout.LayoutParams(0,dp(43),weight).apply { setMargins(dp(2),dp(3),dp(2),dp(3)) }); return b
 }
 override fun onCreate() {
  super.onCreate()
  try { val a=JSONArray(prefs.getString("tabs","[]")); for(i in 0 until minOf(a.length(),12)) { val o=a.getJSONObject(i); tabs.add(Tab(o.getString("url"),o.optString("title"))) } } catch(_:Exception) {}
 }
 override fun onCreateInputView():View {
  root=panel().apply { setPadding(dp(5),dp(5),dp(5),dp(8)); background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(0xff10202b.toInt(),0xff141123.toInt(),0xff08151e.toInt())) }
  draw(); return root
 }
 override fun onEvaluateFullscreenMode()=false
 override fun onStartInput(info:EditorInfo?, restarting:Boolean) {
  super.onStartInput(info,restarting); epoch++
  val type=info?.inputType ?: 0
  val variation=type and InputType.TYPE_MASK_VARIATION
  secret = (type and InputType.TYPE_MASK_CLASS == InputType.TYPE_CLASS_TEXT && variation in listOf(InputType.TYPE_TEXT_VARIATION_PASSWORD,InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) || (type and InputType.TYPE_MASK_CLASS == InputType.TYPE_CLASS_NUMBER && variation==InputType.TYPE_NUMBER_VARIATION_PASSWORD)
  hasSelection = info != null && info.initialSelStart != info.initialSelEnd
  mode="keys"; browserTyping=false; webConnection=null; openSpell()
  if(::root.isInitialized) draw()
 }
 override fun onFinishInput() { epoch++; handler.removeCallbacks(review); spell?.close(); spell=null; super.onFinishInput() }
 override fun onWindowHidden() { tabs.forEach { it.web?.onPause() }; super.onWindowHidden() }
 override fun onWindowShown() { super.onWindowShown(); tabs.getOrNull(selected)?.web?.onResume() }
 override fun onCurrentInputMethodSubtypeChanged(subtype:InputMethodSubtype?) { es=subtype?.locale?.startsWith("en")!=true; openSpell(); if(::root.isInitialized) draw() }
 private fun openSpell() {
  spell?.close(); spell=null
  if(secret) return
  try { spell=(getSystemService(TEXT_SERVICES_MANAGER_SERVICE) as TextServicesManager).newSpellCheckerSession(null,Locale(if(es) "es" else "en"),this,false) } catch(_:Exception) {}
 }
 private fun draw() {
  root.removeAllViews()
  root.addView(row().apply {
   key("⌨") { mode="keys"; browserTyping=false; draw() }
   key("⌕ Buscar") { mode="search"; browserTyping=false; draw() }
   key("▤ ${tabs.size}") { mode="tabs"; draw() }
   key("Historial") { mode="history"; draw() }
   key("⌄",0.6f) { requestHideSelf(0) }
  })
  body=panel(); root.addView(body)
  when(mode) {
   "keys" -> { suggestions=row(); body.addView(suggestions); suggestions.addView(label(if(secret) "Campo privado · revisión desactivada" else "${if(es) "ESPAÑOL" else "ENGLISH"}  ·  AURORA KEY")); keyboard() }
   "search" -> {
    body.addView(label("BÚSQUEDA PRIVADA DEL TECLADO · DUCKDUCKGO"))
    body.addView(row().apply { addView(label(query.ifEmpty { "Busca o escribe una dirección…" }),LinearLayout.LayoutParams(0,dp(48),1f)); key("Ir",0.22f) { navigate(query) } })
    keyboard()
   }
   "tabs", "history" -> listing()
   "web" -> browser()
  }
 }
 private fun keyboard() {
  val rows=if(symbols) listOf("1234567890","@#€%&*+-=",".,:;!?¿¡/") else listOf("qwertyuiop",if(es) "asdfghjklñ" else "asdfghjkl","zxcvbnm")
  rows.forEach { letters -> body.addView(row().apply {
   letters.forEach { c -> val shown=if(shift) c.uppercaseChar().toString() else c.toString(); val b=key(shown) { input(shown) }
    b.setOnLongClickListener {
     val options=when(c) { 'a'->listOf("á","à","â","ä"); 'e'->listOf("é","è","ê","ë"); 'i'->listOf("í","ì","î","ï"); 'o'->listOf("ó","ò","ô","ö"); 'u'->listOf("ú","ü","ù","û"); 'n'->listOf("ñ"); 'c'->listOf("ç"); else->emptyList() }
     if(options.isEmpty()) false else { PopupMenu(this@AuroraIme,b).apply { options.forEach { menu.add(it) }; setOnMenuItemClickListener { input(if(shift) it.title.toString().uppercase() else it.title.toString()); true }; show() }; true }
    }
   }
  }) }
  body.addView(row().apply {
   key(if(shift) "⇧ •" else "⇧",0.9f) { shift=!shift; draw() }
   key(if(symbols) "ABC" else "123",1f) { symbols=!symbols; draw() }
   key(if(es) "ES" else "EN",0.8f) { es=!es; openSpell(); draw() }
   key("espacio",2.7f) { input(" ") }
   key("⌫",0.9f) { if(mode=="search") { query=query.dropLast(1); draw() } else { connection()?.deleteSurroundingText(1,0); schedule() } }
   key("↵",0.9f) { if(mode=="search") navigate(query) else if(browserTyping) connection()?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER)).also { connection()?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER)) } else {
    val action=(currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
    if(action in listOf(EditorInfo.IME_ACTION_DONE,EditorInfo.IME_ACTION_GO,EditorInfo.IME_ACTION_SEARCH,EditorInfo.IME_ACTION_SEND,EditorInfo.IME_ACTION_NEXT)) currentInputConnection?.performEditorAction(action) else input("\n")
   } }
  })
 }
 private fun connection()=if(browserTyping) webConnection else currentInputConnection
 private fun input(s:String) { if(mode=="search") { query+=s; draw() } else { connection()?.commitText(s,1); schedule() } }
 private fun navigate(raw:String) {
  val q=raw.trim(); if(q.isEmpty()) return
  val url=when { q.startsWith("https://") -> q; q.startsWith("http://") -> "https://"+q.removePrefix("http://"); !q.contains(" ") && q.contains(".") && !q.contains(":") -> "https://$q"; else -> "https://duckduckgo.com/?q="+URLEncoder.encode(q,"UTF-8") }
  if(UriSafe(url).not()) return
  if(tabs.size>=12) { Toast.makeText(this,"Máximo 12 pestañas: cierra una para continuar",Toast.LENGTH_SHORT).show(); return }
  tabs.add(Tab(url)); selected=tabs.lastIndex; mode="web"; browserTyping=false; saveTabs(); draw()
 }
 private fun UriSafe(url:String)=try { val u=URI(url); u.scheme=="https" && !u.host.isNullOrEmpty() } catch(_:Exception) { false }
 private fun listing() {
  val list=panel()
  if(mode=="tabs") {
   list.addView(button("+ Nueva búsqueda") { mode="search"; query=""; draw() })
   tabs.forEachIndexed { i,t -> list.addView(row().apply {
    t.icon?.let { bitmap -> addView(ImageView(this@AuroraIme).apply { setImageBitmap(bitmap) },LinearLayout.LayoutParams(dp(28),dp(28))) }
    key("${if(t.icon==null) "◈  " else ""}${t.title}\n${android.net.Uri.parse(t.url).host}",5f) { selected=i; browserTyping=false; mode="web"; draw() }
    key("×") { t.web?.destroy(); tabs.removeAt(i); selected=selected.coerceAtMost((tabs.size-1).coerceAtLeast(0)); saveTabs(); draw() }
   }) }
   if(tabs.isEmpty()) list.addView(label("Tus consultas aparecerán aquí."))
  } else {
   list.addView(button("Borrar historial") { prefs.edit().remove("history").apply(); draw() })
   val history=history()
   for(i in 0 until history.length()) { val o=history.getJSONObject(i); list.addView(button("◷  ${o.optString("title")}\n${android.net.Uri.parse(o.optString("url")).host}") { navigate(o.getString("url")) }) }
   if(history.length()==0) list.addView(label("Todavía no hay páginas visitadas."))
  }
  body.addView(ScrollView(this).apply { addView(list) },LinearLayout.LayoutParams(-1,dp(290)))
 }
 private fun browser() {
  val tab=tabs.getOrNull(selected) ?: run { mode="search"; draw(); return }
  val w=tab.web ?: WebView(this).also { v ->
   tab.web=v
   v.settings.apply { javaScriptEnabled=true; domStorageEnabled=true; allowFileAccess=false; allowContentAccess=false; mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW; setSupportMultipleWindows(false); builtInZoomControls=true; displayZoomControls=false }
   CookieManager.getInstance().setAcceptThirdPartyCookies(v,false)
   v.webViewClient=object:WebViewClient() {
    override fun shouldOverrideUrlLoading(view:WebView,req:WebResourceRequest)=!UriSafe(req.url.toString())
    override fun onPageFinished(view:WebView,url:String) {
     if(!UriSafe(url)) return
     tab.url=url; tab.title=view.title ?: android.net.Uri.parse(url).host ?: "Página"; saveTabs()
     val a=JSONArray(); a.put(JSONObject().put("url",url).put("title",tab.title).put("time",System.currentTimeMillis()))
     val old=history(); for(i in 0 until old.length()) { if(a.length()>=100) break; val o=old.getJSONObject(i); if(o.optString("url")!=url) a.put(o) }
     prefs.edit().putString("history",a.toString()).apply()
    }
   }
   v.webChromeClient=object:WebChromeClient() { override fun onReceivedIcon(view:WebView,icon:Bitmap) { tab.icon=icon } }
   v.loadUrl(tab.url)
  }
  (w.parent as? android.view.ViewGroup)?.removeView(w); w.onResume()
  body.addView(row().apply {
   key("‹",0.6f) { if(w.canGoBack()) w.goBack() }
   key("›",0.6f) { if(w.canGoForward()) w.goForward() }
   key("↻",0.6f) { w.reload() }
   key(if(tall) "Reducir" else "Ampliar") { tall=!tall; draw() }
   key(if(browserTyping) "Ocultar ABC" else "Escribir web",1.4f) {
    browserTyping=!browserTyping
    webConnection=if(browserTyping) w.onCreateInputConnection(EditorInfo()) else null
    draw()
   }
  })
  body.addView(label("${android.net.Uri.parse(tab.url).host} · Mantén pulsado un texto para copiar"))
  body.addView(w,LinearLayout.LayoutParams(-1,dp(if(browserTyping) 170 else if(tall) 430 else 290)))
  if(browserTyping) keyboard()
 }
 private fun history()=try { JSONArray(prefs.getString("history","[]")) } catch(_:Exception) { JSONArray() }
 private fun saveTabs() { val a=JSONArray(); tabs.forEach { a.put(JSONObject().put("url",it.url).put("title",it.title)) }; prefs.edit().putString("tabs",a.toString()).apply() }
 private fun schedule() { epoch++; handler.removeCallbacks(review); if(mode=="keys" && !secret && !browserTyping && !hasSelection) handler.postDelayed(review,900) }
 override fun onUpdateSelection(a:Int,b:Int,c:Int,d:Int,e:Int,f:Int) { super.onUpdateSelection(a,b,c,d,e,f); hasSelection=c!=d; schedule() }
 private val review=Runnable {
  if(secret || hasSelection || mode!="keys") return@Runnable
  val text=currentInputConnection?.getTextBeforeCursor(1200,0)?.toString() ?: return@Runnable
  val token=epoch
  val word=Regex("[\\p{L}]+$").find(text)?.value
  if(word!=null && word.length>2) { lastWord=word; lastContext=text; spellEpoch=token; spell?.getSuggestions(TextInfo(word),3) }
  if(!prefs.getBoolean("grammar",false) || text.length<4) return@Runnable
  val endpoint=prefs.getString("endpoint","") ?: ""; if(!UriSafe(endpoint)) return@Runnable
  val language=if(es) "es" else "en-US"
  network.execute {
   var conn:HttpURLConnection?=null
   try {
    if(token!=epoch || !prefs.getBoolean("grammar",false)) return@execute
    conn=URL(endpoint).openConnection() as HttpURLConnection
    conn.connectTimeout=6000; conn.readTimeout=6000; conn.instanceFollowRedirects=false; conn.requestMethod="POST"; conn.doOutput=true
    conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8")
    conn.outputStream.use { it.write(("language=$language&text="+URLEncoder.encode(text,"UTF-8")).toByteArray(Charsets.UTF_8)) }
    val json=conn.inputStream.bufferedReader().use { JSONObject(it.readText()) }; val matches=json.getJSONArray("matches")
    handler.post {
     if(token!=epoch || secret || mode!="keys") return@post
     suggestions.removeAllViews()
     if(matches.length()==0) suggestions.addView(label("Sin observaciones · $language"))
     for(i in 0 until minOf(matches.length(),2)) {
      val m=matches.getJSONObject(i); val reps=m.getJSONArray("replacements"); if(reps.length()==0) continue
      val replacement=reps.getJSONObject(0).getString("value"); val offset=m.getInt("offset"); val length=m.getInt("length")
      if(offset<0 || offset+length>text.length) continue
      suggestions.key("${text.substring(offset,offset+length)} → $replacement") {
       // Replace only after revalidating context; never rewrite an unseen document.
       val ic=currentInputConnection
       if(ic?.getTextBeforeCursor(1200,0)?.toString()==text && token==epoch) {
        val tail=text.substring(offset+length)
        ic.beginBatchEdit(); ic.deleteSurroundingText(text.length-offset,0); ic.commitText(replacement+tail,1); ic.endBatchEdit(); schedule()
       }
      }
     }
    }
   } catch(_:Exception) { handler.post { if(token==epoch && mode=="keys") { suggestions.removeAllViews(); suggestions.addView(label("Revisión remota no disponible · puedes seguir escribiendo")) } } }
   finally { conn?.disconnect() }
  }
 }
 override fun onGetSuggestions(results:Array<out SuggestionsInfo>?) {
  if(secret || mode!="keys" || spellEpoch!=epoch || currentInputConnection?.getTextBeforeCursor(1200,0)?.toString()!=lastContext) return
  val result=results?.firstOrNull() ?: return
  if(result.suggestionsAttributes and SuggestionsInfo.RESULT_ATTR_LOOKS_LIKE_TYPO==0) return
  suggestions.removeAllViews()
  val original=lastWord; val context=lastContext
  for(i in 0 until minOf(result.suggestionsCount,3)) { val replacement=result.getSuggestionAt(i); suggestions.key(replacement) {
   val ic=currentInputConnection
   if(ic?.getTextBeforeCursor(1200,0)?.toString()==context) { ic.beginBatchEdit(); ic.deleteSurroundingText(original.length,0); ic.commitText(replacement,1); ic.endBatchEdit(); schedule() }
  } }
 }
 override fun onGetSentenceSuggestions(results:Array<out SentenceSuggestionsInfo>?) {}
 override fun onDestroy() { handler.removeCallbacksAndMessages(null); spell?.close(); network.shutdownNow(); tabs.forEach { it.web?.destroy() }; super.onDestroy() }
}
